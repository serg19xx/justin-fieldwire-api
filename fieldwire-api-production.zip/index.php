<?php
// Redirect to public/index.php
require_once __DIR__ . '/public/index.php';
?>
