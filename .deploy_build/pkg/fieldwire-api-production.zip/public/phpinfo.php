<?php
// Test file to check PHP configuration on server
phpinfo();
?>
